import * as cheerio from "cheerio"
import { itemsToRss } from "../rss.js"
import { DateTime } from "luxon"

// 重试函数
async function fetchWithRetry(url, options, maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            // 添加递增延迟
            if (i > 0) {
                await new Promise(resolve => setTimeout(resolve, i * 2000))
            }
            
            const response = await fetch(url, options)
            return response
        } catch (error) {
            console.error(`Fetch attempt ${i + 1} failed:`, error)
            if (i === maxRetries - 1) throw error
        }
    }
}

export async function researchgate(profileId, workerUrl, format) {
    // 添加随机延迟以模拟人类行为
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500))
    
    const requestOptions = {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Sec-Ch-Ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "Referer": "https://www.google.com/"
        },
        cf: {
            // Cloudflare Workers 特有的配置
            cacheEverything: false,
            cacheTtl: 0
        }
    }
    
    let resp
    try {
        resp = await fetchWithRetry(`https://www.researchgate.net/profile/${profileId}`, requestOptions)
    } catch (error) {
        console.error("All fetch attempts failed:", error)
        
        // 创建一个详细的问题说明RSS响应
        const items = [{
            title: `ResearchGate 访问限制说明 - ${profileId}`,
            link: `https://www.researchgate.net/profile/${profileId}`,
            description: `<![CDATA[
                <h3>🔒 ResearchGate 访问限制</h3>
                <p><strong>问题原因：</strong></p>
                <ul>
                    <li>🌍 <strong>地理位置限制：</strong>ResearchGate 对某些地区的服务器访问进行了限制</li>
                    <li>🛡️ <strong>Cloudflare 保护：</strong>ResearchGate 使用 Cloudflare 的高级反爬虫保护</li>
                    <li>🚫 <strong>IP 黑名单：</strong>Cloudflare Workers 的 IP 可能被列入黑名单</li>
                    <li>🤖 <strong>自动检测：</strong>系统检测到非人类访问模式</li>
                </ul>
                
                <h3>💡 替代方案</h3>
                <p><strong>1. 手动访问：</strong></p>
                <ul>
                    <li>直接访问：<a href="https://www.researchgate.net/profile/${profileId}" target="_blank">https://www.researchgate.net/profile/${profileId}</a></li>
                    <li>使用浏览器书签功能定期检查</li>
                </ul>
                
                <p><strong>2. 替代RSS源：</strong></p>
                <ul>
                    <li>🔬 <strong>Google Scholar：</strong> <code>https://scholar.google.com/citations?user=[用户ID]</code></li>
                    <li>📚 <strong>ORCID：</strong> <code>https://orcid.org/[ORCID-ID]</code></li>
                    <li>🎓 <strong>Academia.edu：</strong> 如果研究者有账号</li>
                </ul>
                
                <p><strong>3. 技术解决方案：</strong></p>
                <ul>
                    <li>使用本地脚本配合代理服务器</li>
                    <li>使用第三方API服务（如果可用）</li>
                    <li>等待ResearchGate放宽访问限制</li>
                </ul>
                
                <hr>
                <p><em>📅 检查时间：${new Date().toLocaleString()}</em></p>
                <p><em>🔧 技术状态：ResearchGate 返回 403 Forbidden</em></p>
                <p><em>💭 这是网站的保护机制，不是程序错误</em></p>
            ]]>`,
            author: "RSS Worker 系统",
            guid: `researchgate-blocked-${profileId}-${Date.now()}`,
            pubDate: new Date().toUTCString(),
            enclosure: {
                url: "https://www.researchgate.net/favicon.ico",
                length: "0",
                type: "image/x-icon"
            }
        }]

        const channel = {
            title: `${profileId} - ResearchGate (访问受限)`,
            description: `ResearchGate 个人资料 ${profileId} - 由于网站访问限制无法获取数据`,
            link: `https://www.researchgate.net/profile/${profileId}`,
            image: "https://www.researchgate.net/favicon.ico"
        }

        return itemsToRss(items, channel)
    }
    
    if (!resp.ok) {
        console.error(`ResearchGate fetch failed: ${resp.status} ${resp.statusText}`)
        
        // 创建一个详细的错误分析RSS响应
        let errorAnalysis = '';
        let suggestions = '';
        
        if (resp.status === 403) {
            errorAnalysis = `
                <h3>🚫 403 Forbidden - 访问被拒绝</h3>
                <p><strong>这是最常见的ResearchGate访问问题</strong></p>
                <p><strong>具体原因：</strong></p>
                <ul>
                    <li>🛡️ <strong>Cloudflare防护：</strong>ResearchGate使用Cloudflare的Bot Management</li>
                    <li>🌍 <strong>地理限制：</strong>某些地区的服务器IP被限制</li>
                    <li>🤖 <strong>反爬虫检测：</strong>自动检测到非浏览器访问</li>
                    <li>📊 <strong>频率限制：</strong>请求频率过高触发保护</li>
                </ul>`;
                
            suggestions = `
                <h3>💡 解决建议</h3>
                <p><strong>立即可用的方案：</strong></p>
                <ul>
                    <li>🌐 手动访问：<a href="https://www.researchgate.net/profile/${profileId}" target="_blank">查看原页面</a></li>
                    <li>📱 使用移动端：有时移动版本限制较少</li>
                    <li>🔍 Google Scholar搜索：<a href="https://scholar.google.com/scholar?q=${encodeURIComponent(profileId)}+site:researchgate.net" target="_blank">在Google Scholar中搜索</a></li>
                </ul>
                
                <p><strong>技术替代方案：</strong></p>
                <ul>
                    <li>📚 <strong>ORCID RSS：</strong> 如果研究者有ORCID ID</li>
                    <li>🎓 <strong>Google Scholar RSS：</strong> 使用第三方服务</li>
                    <li>� <strong>邮件通知：</strong> 设置ResearchGate邮件提醒</li>
                    <li>🔖 <strong>浏览器书签：</strong> 定期手动检查</li>
                </ul>`;
        } else if (resp.status === 404) {
            errorAnalysis = `
                <h3>❓ 404 Not Found - 用户不存在</h3>
                <p>指定的用户名可能不存在或已更改</p>`;
            suggestions = `
                <h3>🔍 检查建议</h3>
                <ul>
                    <li>✏️ 检查用户名拼写：<code>${profileId}</code></li>
                    <li>🔍 在ResearchGate搜索该研究者</li>
                    <li>📧 联系研究者获取正确的profile URL</li>
                </ul>`;
        } else if (resp.status === 429) {
            errorAnalysis = `
                <h3>⏰ 429 Too Many Requests - 请求过于频繁</h3>
                <p>触发了ResearchGate的频率限制</p>`;
            suggestions = `
                <h3>⏳ 解决方案</h3>
                <ul>
                    <li>等待一段时间后重试</li>
                    <li>降低RSS更新频率</li>
                    <li>使用手动访问作为临时方案</li>
                </ul>`;
        } else {
            errorAnalysis = `
                <h3>⚠️ HTTP ${resp.status} - ${resp.statusText}</h3>
                <p>遇到了意外的服务器响应</p>`;
            suggestions = `
                <h3>🔧 通用建议</h3>
                <ul>
                    <li>稍后重试</li>
                    <li>检查ResearchGate是否正常运行</li>
                    <li>手动访问确认页面状态</li>
                </ul>`;
        }
        
        const items = [{
            title: `ResearchGate HTTP ${resp.status} 错误 - ${profileId}`,
            link: `https://www.researchgate.net/profile/${profileId}`,
            description: `<![CDATA[
                ${errorAnalysis}
                ${suggestions}
                
                <hr>
                <p><strong>📊 技术详情：</strong></p>
                <ul>
                    <li>状态码：${resp.status}</li>
                    <li>状态信息：${resp.statusText}</li>
                    <li>时间：${new Date().toLocaleString()}</li>
                    <li>目标URL：https://www.researchgate.net/profile/${profileId}</li>
                </ul>
                
                <p><strong>🎯 下一步行动：</strong></p>
                <ol>
                    <li>点击上方链接手动访问页面</li>
                    <li>如果页面正常，说明是自动访问限制</li>
                    <li>考虑使用替代的学术资料RSS源</li>
                    <li>设置浏览器书签定期检查更新</li>
                </ol>
            ]]>`,
            author: "RSS Worker 诊断系统",
            guid: `http-error-${resp.status}-${profileId}-${Date.now()}`,
            pubDate: new Date().toUTCString(),
            enclosure: {
                url: "https://www.researchgate.net/favicon.ico",
                length: "0",
                type: "image/x-icon"
            }
        }]

        const channel = {
            title: `${profileId} - ResearchGate (错误 ${resp.status})`,
            description: `ResearchGate 访问错误 - HTTP ${resp.status}: ${resp.statusText}`,
            link: `https://www.researchgate.net/profile/${profileId}`,
            image: "https://www.researchgate.net/favicon.ico"
        }

        return itemsToRss(items, channel)
    }
    
    const html = await resp.text()
    const $ = cheerio.load(html)
    
    // 获取作者信息
    const authorName = $('h1[itemprop="name"]').text().trim() || profileId
    const affiliation = $('.nova-legacy-v-person-item__stack-item .nova-legacy-e-text').first().text().trim()
    
    const items = []

    // 解析每个出版物
    $('.nova-legacy-v-publication-item').each((i, el) => {
        const $item = $(el)
        
        // 提取标题和链接
        const titleElement = $item.find('.nova-legacy-v-publication-item__title a')
        const title = titleElement.text().trim()
        const link = titleElement.attr('href') || ""
        
        if (!title || !link) return // 跳过无效条目
        
        // 提取出版物类型
        const type = $item.find('.nova-legacy-e-badge').text().trim() || "Publication"
        
        // 提取日期
        const dateText = $item.find('.nova-legacy-v-publication-item__meta-data-item span').text().trim()
        let pubDate = ""
        if (dateText) {
            try {
                // 处理各种日期格式：Sep 2025, September 2025, 2025等
                const dateMatch = dateText.match(/(\w+)\s+(\d{4})/)
                if (dateMatch) {
                    const [, month, year] = dateMatch
                    const date = DateTime.fromObject({ 
                        year: parseInt(year), 
                        month: DateTime.fromFormat(month, 'MMM').month || DateTime.fromFormat(month, 'MMMM').month || 1
                    })
                    if (date.isValid) {
                        pubDate = date.toRFC2822()
                    }
                } else if (/^\d{4}$/.test(dateText)) {
                    // 只有年份的情况
                    const date = DateTime.fromObject({ year: parseInt(dateText), month: 1 })
                    if (date.isValid) {
                        pubDate = date.toRFC2822()
                    }
                }
            } catch (e) {
                console.error("Date parsing error:", e)
            }
        }
        
        // 提取作者列表
        const authors = []
        $item.find('.nova-legacy-v-person-inline-item__fullname').each((j, authorEl) => {
            const authorName = $(authorEl).text().trim()
            if (authorName && authorName !== '[...]') {
                authors.push(authorName)
            }
        })
        
        // 生成描述
        const description = `
            <![CDATA[
                <p><strong>Type:</strong> ${type}</p>
                <p><strong>Authors:</strong> ${authors.join(', ')}</p>
                <p><strong>Publication Date:</strong> ${dateText || 'Not specified'}</p>
                <p><a href="${link}" target="_blank">View on ResearchGate</a></p>
            ]]>
        `
        
        items.push({
            title: title,
            link: link.startsWith('http') ? link : `https://www.researchgate.net${link}`,
            description: description,
            author: authors.join(', ') || authorName,
            guid: link,
            pubDate: pubDate || new Date().toUTCString(),
            enclosure: {
                url: "https://www.researchgate.net/favicon.ico",
                length: "0",
                type: "image/x-icon"
            }
        })
    })

    // 构建频道信息
    const channel = {
        title: `${authorName} - ResearchGate Publications`,
        description: `Research publications by ${authorName}${affiliation ? ` (${affiliation})` : ''} on ResearchGate`,
        link: `https://www.researchgate.net/profile/${profileId}`,
        image: "https://www.researchgate.net/favicon.ico"
    }

    return itemsToRss(items, channel)
}