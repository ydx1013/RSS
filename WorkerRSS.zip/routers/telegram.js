import * as cheerio from "cheerio"
import { itemsToRss } from "../rss.js"
import { DateTime } from "luxon"

export async function telegram(ID, workerUrl, format) {
    const resp = await fetch(`https://t.me/s/${ID}`)
    const html = await resp.text()
    const $ = cheerio.load(html)
    const fullTitle = $("title").text().trim()
    const title = fullTitle.split(" ")[0]  // 取第一个空格前的部分
    const description = $('meta[name="description"]').attr("content") || "无"
    const items = []

    $(".tgme_widget_message_wrap").each((i, el) => {
        const link = $(el).find("a.tgme_widget_message_date").attr("href") || ""
        const author = $(el).find(".tgme_widget_message_owner_name").text().trim() || ""
        const datetime = $(el).find("time").attr("datetime") || ""
        const rssTime = datetime ? DateTime.fromISO(datetime, { zone: "utc" }).toRFC2822() : ""

        // 获取消息文本元素
        const textElement = $(el).find(".tgme_widget_message_text")

        // 处理投票
        const pollElement = $(el).find(".tgme_widget_message_poll")
        let pollContent = ""
        
        // 智能提取标题
        let itemTitle = "无标题"

        if (pollElement.length > 0) {
            const pollQuestion = pollElement.find(".tgme_widget_message_poll_question").text().trim()
            if (pollQuestion) {
                itemTitle = `[投票] ${pollQuestion}`
            }

            const pollOptions = []
            pollElement.find(".tgme_widget_message_poll_option").each((i, optionEl) => {
                const optionText = $(optionEl).find(".tgme_widget_message_poll_option_text").text().trim()
                pollOptions.push(`<li>${optionText}</li>`)
            })

            const pollVotes = pollElement.find(".tgme_widget_message_poll_votes").text().trim()

            pollContent = `
                <br>
                <div style="border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                    <h4>${pollQuestion}</h4>
                    <ul>${pollOptions.join('')}</ul>
                    <p><strong>${pollVotes}</strong></p>
                </div>
            `
        }
        
        // 方法1：寻找包含实际文字内容的<b>标签（排除只有emoji的<b>标签）
        const boldElements = textElement.find("b")
        let foundTitle = false
        
        boldElements.each((index, boldEl) => {
            const boldText = $(boldEl).text().trim()
            // 如果<b>标签内容长度大于3且包含非emoji字符，认为是标题
            if (boldText.length > 3 && /[\u4e00-\u9fff\w]/.test(boldText)) {
                itemTitle = boldText
                foundTitle = true
                return false // 找到就退出循环
            }
        })
        
        // 方法2：如果没找到合适的<b>标签，尝试从文本中提取标题
        if (!foundTitle) {
            const fullText = textElement.text().trim()
            if (fullText) {
                // 移除开头的emoji和空白字符，取第一行有实际内容的文本
                const lines = fullText.split('\n')
                for (let line of lines) {
                    const cleanLine = line.trim()
                    // 寻找第一行有实际文字内容的行作为标题
                    if (cleanLine.length > 5 && /[\u4e00-\u9fff\w]/.test(cleanLine)) {
                        itemTitle = cleanLine
                        break
                    }
                }
            }
        }

        // 获取完整的HTML内容
        let htmlContent = textElement.html() || ""
        
        // 处理图片
        const photo = $(el).find("a.tgme_widget_message_photo_wrap").css("background-image") || ""
        const photoUrl = photo.replace(/^url\(['"]?/, "").replace(/['"]?\)$/, "")

        // 处理视频
        const video = $(el).find(".tgme_widget_message_video_wrap video").attr("src") || ""
        
        // 组合内容
        let contentParts = []
        if (htmlContent) {
            contentParts.push(htmlContent)
        }
        if (pollContent) {
            contentParts.push(pollContent)
        }
        if (photoUrl) {
            contentParts.push(`<br><img src="${photoUrl}" style="max-width: 100%; height: auto;" />`)
        }
        if (video) {
            contentParts.push(`<br><video controls style="max-width: 100%; height: auto;"><source src="${video}" type="video/mp4" /></video>`)
        }

        const content = `<![CDATA[${contentParts.join('')}]]>`

        // 确定enclosure（优先级：图片 > 视频 > 默认logo）
        let enclosureUrl = "https://telegram.org/img/t_logo.png"
        let enclosureType = "image/png"
        
        if (photoUrl) {
            enclosureUrl = photoUrl
            enclosureType = "image/jpeg"
        } else if (video) {
            enclosureUrl = video
            enclosureType = "video/mp4"
        }

        items.push({
            title: itemTitle,
            link: link,
            description: content,
            author: author,
            guid: link,
            pubDate: rssTime,
            enclosure: {
                url: enclosureUrl,
                length: "0",
                type: enclosureType
            }
        })
    })

    const channel = {
        title: `${title} - Telegram`,
        description: `${title} - Telegram`,
        link: `https://t.me/s/${ID}`,
        image: "https://telegram.org/img/t_logo.png"
    }

    return itemsToRss(items, channel, format)
}
