// config.js
// 缓存时间配置 (单位: 秒)

export const cacheConfig = {
    // 默认缓存时间，适用于未在下面单独配置的路由
    default: {
        success: 28800, // 成功时默认缓存 8 小时
        error: 600,     // 失败时默认缓存 10 分钟
    },
    
    // 为特定路由单独配置缓存时间
    routes: {
        // 爱Q生活网，更新频繁，缓存设置短一些
        iqnew: {
            success: 7200,  // 2 小时
            error: 300,     // 5 分钟
        },
        // GitHub Release, 更新不频繁，可以设置长一些
        github: {
            success: 43200, // 12 小时
            error: 1800,    // 30 分钟
        },
        // 示例：如果某个路由想用默认值，则无需在此处配置
        // dlsite: { ... } 
    }
};
